from models.dacg_net import DaCGNetModel, build_dacg_model, set_dacg_finetune_trainable
CNN_RNN_Model = DaCGNetModel

def build_baseline_model(device):
    return build_dacg_model(device)

def set_baseline_trainable(model, trainable_mode):
    if trainable_mode == 'predictor':
        return set_dacg_finetune_trainable(model)
    if trainable_mode != 'all':
        raise ValueError(trainable_mode)
    for p in model.parameters():
        p.requires_grad_(True)
    return list(model.parameters())
