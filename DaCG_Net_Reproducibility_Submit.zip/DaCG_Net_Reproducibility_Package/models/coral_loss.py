import torch
from torch import nn

def coral_loss(source, target):
    if source.ndim != 2 or target.ndim != 2 or source.shape[1] != target.shape[1]:
        raise ValueError('CORAL needs [samples, features] with matching widths.')
    if min(len(source), len(target)) < 2 or source.shape[1] == 0:
        raise ValueError('Unbiased CORAL needs at least two samples per domain.')
    sc = source - source.mean(0, keepdim=True)
    tc = target - target.mean(0, keepdim=True)
    cs = sc.T @ sc / (len(source) - 1)
    ct = tc.T @ tc / (len(target) - 1)
    return (cs - ct).square().sum() / (4 * source.shape[1] ** 2)

class CORALLoss(nn.Module):

    def forward(self, source, target):
        return coral_loss(source, target)
