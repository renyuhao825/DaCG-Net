import torch
import torch.nn as nn
from typing import List, Tuple, Optional
from models.coral_loss import coral_loss

def weights_init(module: nn.Module) -> None:
    if isinstance(module, (nn.Conv2d, nn.Linear)):
        nn.init.xavier_normal_(module.weight.data)
        if module.bias is not None:
            nn.init.constant_(module.bias.data, 0.0)
    elif isinstance(module, nn.GRU):
        for name, param in module.named_parameters():
            if 'weight' in name:
                nn.init.xavier_normal_(param.data)
            elif 'bias' in name:
                nn.init.constant_(param.data, 0.0)

class DaCGNetModel(nn.Module):

    def __init__(self, dropout_rate: float=0.9):
        super().__init__()
        self.cnn1 = nn.Sequential(nn.Conv2d(1, 64, kernel_size=(2, 2), padding='same'), nn.ReLU(), nn.Conv2d(64, 64, kernel_size=(2, 2), padding='same'), nn.ReLU(), nn.MaxPool2d(kernel_size=2), nn.Flatten())
        self.fc1 = nn.Sequential(nn.Linear(2816, 512), nn.Dropout(p=dropout_rate), nn.ReLU(), nn.Linear(512, 256), nn.Dropout(p=dropout_rate), nn.ReLU(), nn.Linear(256, 64), nn.Dropout(p=dropout_rate), nn.ReLU(), nn.Linear(64, 4))
        self.gru1 = nn.GRU(4, 64, batch_first=True)
        self.relu1 = nn.ReLU()
        self.gru2 = nn.GRU(64, 64, batch_first=True)
        self.relu2 = nn.ReLU()
        self.fc2 = nn.Sequential(nn.Linear(64, 256), nn.ReLU(), nn.Linear(256, 128), nn.ReLU(), nn.Linear(128, 64), nn.ReLU(), nn.Linear(64, 4))
        self.fc = nn.Sequential(nn.Linear(23, 512), nn.ReLU(), nn.Linear(512, 256), nn.ReLU(), nn.Linear(256, 128), nn.ReLU())
        self.bottleneck = nn.Sequential(nn.Linear(128, 64), nn.ReLU())
        self.final_fc = nn.Sequential(nn.Linear(64, 4))

    def encode(self, past_parameters_cnn_input: torch.Tensor, past_pressure_rnn_input: torch.Tensor, past_pressure_crnn_input: torch.Tensor) -> torch.Tensor:
        cnn_feat = self.fc1(self.cnn1(past_parameters_cnn_input))
        rnn_out1, _ = self.gru1(past_pressure_rnn_input)
        rnn_act1 = self.relu1(rnn_out1)
        rnn_out2, _ = self.gru2(rnn_act1)
        rnn_last = rnn_out2[:, -1, :]
        rnn_feat = self.fc2(self.relu2(rnn_last))
        fused_input = torch.cat((cnn_feat, rnn_feat, past_pressure_crnn_input), dim=1)
        deep_fused = self.fc(fused_input)
        bottleneck_feat = self.bottleneck(deep_fused)
        return bottleneck_feat

    def forward(self, past_parameters_cnn_input_s: torch.Tensor, past_pressure_rnn_input_s: torch.Tensor, past_pressure_crnn_input_s: torch.Tensor, past_parameters_cnn_input_t: Optional[torch.Tensor]=None, past_pressure_rnn_input_t: Optional[torch.Tensor]=None, past_pressure_crnn_input_t: Optional[torch.Tensor]=None) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        source_bottleneck = self.encode(past_parameters_cnn_input_s, past_pressure_rnn_input_s, past_pressure_crnn_input_s)
        source_pred = self.final_fc(source_bottleneck)
        if past_parameters_cnn_input_t is None:
            return (source_pred, None)
        target_bottleneck = self.encode(past_parameters_cnn_input_t, past_pressure_rnn_input_t, past_pressure_crnn_input_t)
        c_loss = coral_loss(source_bottleneck, target_bottleneck)
        return (source_pred, c_loss)

def build_dacg_model(device: torch.device) -> DaCGNetModel:
    model = DaCGNetModel()
    model.apply(weights_init)
    return model.to(device)

def set_dacg_finetune_trainable(model: DaCGNetModel) -> List[nn.Parameter]:
    for param in model.parameters():
        param.requires_grad = False
    for param in model.fc.parameters():
        param.requires_grad = True
    for param in model.bottleneck.parameters():
        param.requires_grad = True
    for param in model.final_fc.parameters():
        param.requires_grad = True
    trainable_params = list(model.fc.parameters()) + list(model.bottleneck.parameters()) + list(model.final_fc.parameters())
    return trainable_params

def verify_dacg_parameters(model: DaCGNetModel) -> dict:
    total_params = sum((p.numel() for p in model.parameters()))
    finetune_params = sum((p.numel() for layer in (model.fc, model.bottleneck, model.final_fc) for p in layer.parameters()))
    finetune_ratio = finetune_params / total_params
    assert total_params == 1888588, f'Expected 1,888,588 parameters, got {total_params}'
    assert finetune_params == 185028, f'Expected 185,028 trainable parameters, got {finetune_params}'
    return {'total_parameters': total_params, 'finetune_parameters': finetune_params, 'finetune_ratio': finetune_ratio}
