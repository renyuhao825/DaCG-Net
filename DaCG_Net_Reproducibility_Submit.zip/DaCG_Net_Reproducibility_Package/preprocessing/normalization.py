from dataclasses import dataclass, asdict
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from preprocessing.schema import FEATURES, COEFFICIENTS, SENSORS, ANGLES
from preprocessing.pressure import fit_pressure_coefficients

@dataclass
class MachineParameters:
    cutter_diameter_m: float = 6.6
    cutter_open_ratio: float = 0.3
    upper_gate_stroke_mm: float = 560.0
    lower_gate_stroke_mm: float = 560.0
    screw_diameter_m: float = 0.8
    screw_pitch_m: float = 0.6
    torque_coefficient: float = 0.67
    pressure_convention: str = 'table2_literal'
    pressure_reference_radius_m: float = 1.0

    def __post_init__(self):
        positive = [self.cutter_diameter_m, self.upper_gate_stroke_mm, self.lower_gate_stroke_mm, self.screw_diameter_m, self.screw_pitch_m, self.torque_coefficient, self.pressure_reference_radius_m]
        if not np.isfinite(positive).all() or min(positive) <= 0:
            raise ValueError('Machine lengths and coefficients must be positive.')
        if not 0 <= self.cutter_open_ratio < 1:
            raise ValueError('Opening ratio must be in [0,1).')

def _positive_divide(a, b, name):
    a, b = (np.asarray(a, dtype=float), np.asarray(b, dtype=float))
    if not np.isfinite(a).all() or not np.isfinite(b).all() or (b <= 0).any():
        raise ValueError(name + ': finite inputs and positive denominator required.')
    return a / b

class DimensionlessPreprocessor:

    def __init__(self, machine=None):
        self.machine = machine if isinstance(machine, MachineParameters) else MachineParameters(**machine or {})

    def compute_dimensionless_features(self, df):
        m = self.machine
        out = df.copy()
        r = m.cutter_diameter_m / 2
        area = np.pi * r ** 2
        advance_m_min = df['Advance_mm_min'].to_numpy() / 1000
        ps_pa = df['Static_Earth_Pressure_kPa'].to_numpy() * 1000
        excavated = advance_m_min * area
        for raw, name in [('Bentonite_m3_min', 'Bentonite_Ratio'), ('Foam_Liquid_m3_min', 'Foam_Liquid_Ratio'), ('Foam_Air_m3_min', 'Foam_Air_Ratio')]:
            out[name] = _positive_divide(df[raw], excavated, raw)
        out['Thrust_Ratio'] = _positive_divide(df['Total_Thrust_kN'] * 1000, area * ps_pa, 'thrust')
        out['Penetration_Ratio'] = _positive_divide(advance_m_min, df['Cutter_RPM'] * 2 * np.pi * r, 'penetration')
        out['Torque_Ratio'] = _positive_divide(df['Cutter_Torque_kNm'] * 1000, (1 - m.cutter_open_ratio) * m.torque_coefficient * np.pi * r ** 3 * ps_pa, 'torque')
        out['Screw_Discharge_Ratio'] = _positive_divide(np.pi * m.screw_diameter_m ** 2 / 4 * df['Screw_RPM'] * m.screw_pitch_m, excavated, 'discharged / excavated volume')
        for axis, a, c in [('Vertical', 'A', 'C'), ('Horizontal', 'B', 'D')]:
            pa, pc = (df[f'Thrust_{a}_MPa'], df[f'Thrust_{c}_MPa'])
            out[f'{axis}_Thrust_Moment'] = _positive_divide(pa - pc, pa + pc, 'thrust moment')
            out[f'{axis}_Displacement_Bias'] = (df[f'Displacement_{a}_mm'] - df[f'Displacement_{c}_mm']) / (2000 * r)
        out['Gate_Upper_Ratio'] = df['Gate_Upper_mm'] / m.upper_gate_stroke_mm
        out['Gate_Lower_Ratio'] = df['Gate_Lower_mm'] / m.lower_gate_stroke_mm
        out['Gate_Combined_Ratio'] = out['Gate_Upper_Ratio'] * out['Gate_Lower_Ratio']
        out['Roll_rad'] = np.deg2rad(df['Roll_deg'])
        out['Pitch_rad'] = np.deg2rad(df['Pitch_deg'])
        coeff, quality = fit_pressure_coefficients(df, m.pressure_convention, m.pressure_reference_radius_m)
        out[COEFFICIENTS] = coeff
        out['Fitting_R2'] = quality
        if not np.isfinite(out[FEATURES + COEFFICIENTS].to_numpy()).all():
            raise ValueError('Non-finite transformed feature.')
        return out

class FittedScalers:

    def __init__(self, method='dimensionless'):
        self.method = method
        self.x = StandardScaler() if method == 'raw_zscore' else MinMaxScaler()
        self.y = MinMaxScaler()

    def fit(self, training_frames):
        if not training_frames or any((len(f) == 0 for f in training_frames)):
            raise ValueError('Scaler fitting requires nonempty training partitions.')
        frame = pd.concat(training_frames, ignore_index=True)
        self.x.fit(frame[FEATURES].to_numpy())
        self.y.fit(frame[COEFFICIENTS].to_numpy())
        return self

    def transform(self, frame):
        out = frame.copy()
        out[FEATURES] = self.x.transform(frame[FEATURES].to_numpy())
        out[COEFFICIENTS] = self.y.transform(frame[COEFFICIENTS].to_numpy())
        return out

    def inverse_coefficients(self, values):
        return self.y.inverse_transform(values)

    def state_dict(self):
        return {'method': self.method, 'features': FEATURES, 'coefficients': COEFFICIENTS, 'x_class': type(self.x).__name__, 'x': {k: v.tolist() if hasattr(v, 'tolist') else v for k, v in vars(self.x).items()}, 'y': {k: v.tolist() if hasattr(v, 'tolist') else v for k, v in vars(self.y).items()}}

    @classmethod
    def from_state_dict(cls, state):
        if state['features'] != FEATURES or state['coefficients'] != COEFFICIENTS:
            raise ValueError('Checkpoint feature schema mismatch.')
        obj = cls(state['method'])
        for scaler, attrs in [(obj.x, state['x']), (obj.y, state['y'])]:
            for key, value in attrs.items():
                setattr(scaler, key, np.asarray(value) if isinstance(value, list) else value)
        return obj
RAW_ABLATION_COLUMNS = ['Bentonite_m3_min', 'Foam_Liquid_m3_min', 'Foam_Air_m3_min', 'Total_Thrust_kN', 'Thrust_A_MPa', 'Thrust_B_MPa', 'Advance_mm_min', 'Gate_Upper_mm', 'Gate_Lower_mm', 'Screw_RPM', 'Cover_Depth_m', 'Groundwater_Depth_m', 'Static_Earth_Pressure_kPa', 'Face_Strength_MPa', 'SPT', 'Cutter_Torque_kNm', 'Displacement_A_mm', 'Displacement_B_mm', 'Roll_deg', 'Pitch_deg', 'Poisson_Ratio', 'Cutter_RPM']

def prepare_frame(df, machine, input_stage='raw', method='dimensionless'):
    df = df.copy()
    if 'Row_ID' in df or df['Sample_Index'].duplicated().any():
        raise ValueError('Sample_Index must be unique; Row_ID is reserved.')
    if not df['Sample_Index'].is_monotonic_increasing:
        raise ValueError('CSV must be ordered by increasing Sample_Index.')
    df['Row_ID'] = np.arange(len(df))
    df['Pressure_Reference_kPa'] = df['Static_Earth_Pressure_kPa'].to_numpy().copy()
    if input_stage == 'raw':
        out = DimensionlessPreprocessor(machine).compute_dimensionless_features(df)
        if method == 'raw_zscore':
            out[FEATURES] = df[RAW_ABLATION_COLUMNS].to_numpy(dtype=float)
        return out
    if input_stage != 'dimensionless' or method != 'dimensionless':
        raise ValueError('Use raw input for raw_zscore; scaled inputs are not accepted.')
    required = FEATURES + COEFFICIENTS + SENSORS + ANGLES + ['Fitting_R2']
    if not all((c in df for c in required)) or not np.isfinite(df[required].to_numpy()).all():
        raise ValueError('Incomplete or non-finite dimensionless input.')
    spec = machine if isinstance(machine, MachineParameters) else MachineParameters(**machine)
    coeff, quality = fit_pressure_coefficients(df, spec.pressure_convention, spec.pressure_reference_radius_m)
    if not np.allclose(df[COEFFICIENTS], coeff, atol=1e-05, rtol=0.0001):
        raise ValueError('Supplied unscaled coefficients do not match sensor geometry/pressure convention.')
    if not np.allclose(df['Fitting_R2'], quality, atol=1e-05, rtol=0.0001):
        raise ValueError('Supplied Fitting_R2 cannot be reproduced from sensor pressures.')
    return df
