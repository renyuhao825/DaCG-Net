import numpy as np
from preprocessing.schema import ANGLES, RADII
DEFAULT_SENSOR_RADIUS_M = 3.14

def design_matrix(angles_deg):
    theta = np.deg2rad(np.asarray(angles_deg, dtype=float))
    if theta.shape[-1] != 6 or not np.isfinite(theta).all():
        raise ValueError('Exactly six finite sensor angles are required.')
    return np.stack([np.ones_like(theta), np.cos(theta), np.sin(theta), np.cos(2 * theta)], axis=-1)

def physical_design(df, convention, reference_radius_m=1.0):
    design = design_matrix(df[ANGLES].to_numpy())
    if convention == 'angular_bar':
        return design
    if convention != 'table2_literal':
        raise ValueError('Unknown pressure convention: ' + convention)
    present = [name in df for name in RADII]
    if any(present) and (not all(present)):
        raise ValueError('Supply all six sensor radii, or omit all to use r=3.14 m.')
    radius = df[RADII].to_numpy(dtype=float) if all(present) else np.full((len(df), 6), DEFAULT_SENSOR_RADIUS_M)
    reference = 'Pressure_Reference_kPa' if 'Pressure_Reference_kPa' in df else 'Static_Earth_Pressure_kPa'
    ps_bar = df[reference].to_numpy(dtype=float) / 100.0
    if not np.isfinite(reference_radius_m) or not np.isfinite(radius).all() or (not np.isfinite(ps_bar).all()) or (reference_radius_m <= 0) or (radius <= 0).any() or (ps_bar <= 0).any():
        raise ValueError('Positive radius, reference radius and earth pressure required.')
    scale = np.log(radius / reference_radius_m) / ps_bar[:, None]
    if (np.abs(scale) < 1e-10).any():
        raise ValueError('log(r/r_ref)=0 makes this sensor design degenerate.')
    return design * scale[..., None]

def fit_pressure_coefficients(df, convention='table2_literal', reference_radius_m=1.0):
    from preprocessing.schema import SENSORS
    design = physical_design(df, convention, reference_radius_m)
    measured = df[SENSORS].to_numpy(dtype=float)
    if not np.isfinite(measured).all():
        raise ValueError('Non-finite measured pressure.')
    coeff = []
    for a, y in zip(design, measured):
        if np.linalg.matrix_rank(a) != 4 or np.linalg.cond(a) > 100000000.0:
            raise ValueError('Sensor geometry cannot reliably identify four coefficients.')
        coeff.append(np.linalg.lstsq(a, y, rcond=None)[0])
    coeff = np.asarray(coeff)
    fitted = np.einsum('nij,nj->ni', design, coeff)
    denom = ((measured - measured.mean(1, keepdims=True)) ** 2).sum(1)
    if (denom < 1e-12).any():
        raise ValueError('Spatial R2 is undefined for constant sensor pressure.')
    quality = 1 - ((measured - fitted) ** 2).sum(1) / denom
    return (coeff, quality)

def reconstruct(coeff, df, convention='table2_literal', reference_radius_m=1.0):
    return np.einsum('nij,nj->ni', physical_design(df, convention, reference_radius_m), np.asarray(coeff))
