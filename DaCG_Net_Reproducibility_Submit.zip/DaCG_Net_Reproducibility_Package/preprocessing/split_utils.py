import numpy as np
from preprocessing.schema import FEATURES, COEFFICIENTS, SENSORS

def split_records(df, fractions):
    result = {}
    for name, (start, end) in fractions.items():
        if not 0 <= start < end <= 1:
            raise ValueError('Invalid split interval: ' + name)
        result[name] = df.iloc[int(len(df) * start):int(len(df) * end)].copy()
    keys = list(result)
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            if set(result[a]['Row_ID']) & set(result[b]['Row_ID']):
                raise ValueError('Overlapping raw record partitions.')
    return result

def window_records(df, r2_threshold=0.99, window_length=9):
    if window_length != 9:
        raise ValueError('Fixed architecture requires eight past rows plus current row.')
    batches = []
    rows = []
    for i in range(len(df) - 8):
        w = df.iloc[i:i + 9]
        if w['Excavation_Ring'].nunique() != 1:
            continue
        if not (np.diff(w['Row_ID'].to_numpy()) == 1).all():
            continue
        if not (w['Fitting_R2'] >= r2_threshold).all():
            continue
        batches.append(w)
        rows.append(w['Row_ID'].to_numpy())
    if len(batches) < 2:
        raise ValueError(f'Only {len(batches)} valid windows in {len(df)} rows. Each partition needs at least two windows. Ten-row excerpts are for inference/schema checks; generate runtime synthetic data or supply sufficient authorized project records for training.')
    return {'x_cnn': np.stack([w[FEATURES].to_numpy()[:8] for w in batches])[:, None].astype('float32'), 'x_rnn': np.stack([w[COEFFICIENTS].to_numpy()[:8] for w in batches]).astype('float32'), 'x_crnn': np.stack([w[FEATURES].to_numpy()[-1, :15] for w in batches]).astype('float32'), 'y': np.stack([w[COEFFICIENTS].to_numpy()[-1] for w in batches]).astype('float32'), 'y_sensors': np.stack([w[SENSORS].to_numpy()[-1] for w in batches]), 'row_ids': np.stack(rows), 'current_frame': df.loc[[w.index[-1] for w in batches]].copy()}
