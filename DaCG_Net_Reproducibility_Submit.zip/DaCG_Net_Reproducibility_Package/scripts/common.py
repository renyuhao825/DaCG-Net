import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import copy
import hashlib
import json
import random
import sys
from pathlib import Path
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, 'reconfigure'):
        stream.reconfigure(encoding='utf-8')
import numpy as np
import torch
ROOT = Path(__file__).resolve().parents[1]
MODES = ['dacg', 'coral_only', 'finetune_only', 'target_only']

def load_config(settings=None, data_dir=None):
    # Internal execution defaults; no external hyperparameter configuration is loaded.
    if settings is not None:
        if not isinstance(settings, dict):
            raise TypeError('External hyperparameter configuration files are not supported.')
        return copy.deepcopy(settings)
    cfg = {'metadata': {'version': 3},
     'architecture': {'cnn_channels': 64,
                      'cnn_kernel_size': [2, 2],
                      'cnn_layers': 2,
                      'cnn_fc_dims': [2112, 512, 256, 64, 4],
                      'cnn_dropout': 0.9,
                      'gru_layers': 2,
                      'gru_hidden_size': 64,
                      'gru_fc_dims': [64, 256, 128, 64, 4],
                      'fusion_fc_dims': [23, 512, 256, 128],
                      'bottleneck_dim': 64,
                      'output_dim': 4},
     'hyperparameters': {'pretrain_learning_rate': 0.01,
                         'finetune_learning_rate': 0.001,
                         'batch_size': 64,
                         'coral_lambda': 0.01,
                         'scheduler': 'CosineAnnealingLR',
                         'scheduler_eta_min': 0.0,
                         'early_stopping_patience': 10,
                         'max_epochs': 100},
     'execution': {'seeds': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 'cpu_threads': 1},
     'preprocessing': {'input_stage': 'raw', 'method': 'dimensionless', 'r2_threshold': 0.99},
     'splits': {'source': {'train': [0.0, 0.9], 'val': [0.9, 1.0]},
                'target': {'train': [0.0, 0.08], 'val': [0.08, 0.1], 'test': [0.1, 0.2]}},
     'sensor_layouts_deg': {'CS-L1': [30, 90, 110, 190, 240, 260],
                            'TJ-L6': [10, 60, 100, 210, 240, 290],
                            'HF-L7': [30, 80, 140, 210, 270, 330]},
     'tasks': {'CS-L1': {'source_csv': '../data/demo_dataset/demo_source_data.csv',
                         'target_csv': '../data/demo_dataset/demo_target_data.csv',
                         'data_kind': 'synthetic_excerpt',
                         'source_machine': {},
                         'target_machine': {}},
               'TJ-L6': {'source_csv': '../data/authorized/source.csv',
                         'target_csv': '../data/authorized/TJ-L6.csv',
                         'data_kind': 'authorized_project_required',
                         'source_machine': {},
                         'target_machine': {}},
               'HF-L7': {'source_csv': '../data/authorized/source.csv',
                         'target_csv': '../data/authorized/HF-L7.csv',
                         'data_kind': 'authorized_project_required',
                         'source_machine': {},
                         'target_machine': {}}}}
    for task in cfg['tasks'].values():
        for key in ['source_csv', 'target_csv']:
            task[key] = str((ROOT / 'configs' / task[key]).resolve())
    if data_dir is not None:
        folder = Path(data_dir).resolve()
        synthetic = (folder / 'SYNTHETIC_PROVENANCE.json').exists()
        for task_id, task in cfg['tasks'].items():
            task['source_csv'] = str(folder / ('synthetic_source.csv' if synthetic else 'source.csv'))
            task['target_csv'] = str(folder / (f'synthetic_{task_id}.csv' if synthetic else f'{task_id}.csv'))
            task['data_kind'] = 'synthetic' if synthetic else 'authorized_project'
    return cfg

def set_seed(seed, threads=1):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(threads)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def code_fingerprint():
    digest = hashlib.sha256()
    for folder in ['models', 'preprocessing', 'scripts']:
        for path in sorted((ROOT / folder).glob('*.py')):
            digest.update(path.relative_to(ROOT).as_posix().encode())
            digest.update(path.read_bytes())
    return digest.hexdigest()

def json_dump(path, obj):

    def convert(x):
        if isinstance(x, (np.integer, np.floating)):
            return x.item()
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, Path):
            return str(x)
        raise TypeError(type(x).__name__)
    Path(path).write_text(json.dumps(obj, indent=2, default=convert, allow_nan=False), encoding='utf-8')

def parse_seeds(value):
    if '-' in value:
        a, b = map(int, value.split('-'))
        seeds = list(range(a, b + 1))
    else:
        seeds = list(map(int, value.split(',')))
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError('Provide nonempty, distinct seeds.')
    return seeds
