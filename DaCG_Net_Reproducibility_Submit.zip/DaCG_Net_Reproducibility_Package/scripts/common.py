import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import copy
import hashlib
import json
import random
import sys
from pathlib import Path
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, 'reconfigure'):
        stream.reconfigure(encoding='utf-8')
import numpy as np
import torch
import yaml
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / 'configs/dacg_benchmark_config.yaml'
MODES = ['dacg', 'coral_only', 'finetune_only', 'target_only']

def load_config(path=DEFAULT_CONFIG):
    path = Path(path).resolve()
    cfg = yaml.safe_load(path.read_text(encoding='utf-8'))
    cfg['_config_path'] = str(path)
    for task in cfg['tasks'].values():
        for key in ['source_csv', 'target_csv']:
            task[key] = str((path.parent / task[key]).resolve())
    expected = {'cnn_channels': 64, 'cnn_kernel_size': [2, 2], 'cnn_layers': 2, 'cnn_fc_dims': [2816, 512, 256, 64, 4], 'cnn_dropout': 0.9, 'gru_layers': 2, 'gru_hidden_size': 64, 'gru_fc_dims': [64, 256, 128, 64, 4], 'fusion_fc_dims': [23, 512, 256, 128], 'bottleneck_dim': 64, 'output_dim': 4}
    if cfg['architecture'] != expected:
        raise ValueError('This release fixes the architecture; structural configuration changes are rejected.')
    return cfg

def set_seed(seed, threads=1):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(threads)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def code_fingerprint():
    digest = hashlib.sha256()
    for folder in ['models', 'preprocessing', 'scripts']:
        for path in sorted((ROOT / folder).glob('*.py')):
            digest.update(path.relative_to(ROOT).as_posix().encode())
            digest.update(path.read_bytes())
    return digest.hexdigest()

def json_dump(path, obj):

    def convert(x):
        if isinstance(x, (np.integer, np.floating)):
            return x.item()
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, Path):
            return str(x)
        raise TypeError(type(x).__name__)
    Path(path).write_text(json.dumps(obj, indent=2, default=convert, allow_nan=False), encoding='utf-8')

def parse_seeds(value):
    if '-' in value:
        a, b = map(int, value.split('-'))
        seeds = list(range(a, b + 1))
    else:
        seeds = list(map(int, value.split(',')))
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError('Provide nonempty, distinct seeds.')
    return seeds
