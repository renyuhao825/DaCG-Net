import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
import torch
from models.dacg_net import build_dacg_model, verify_dacg_parameters
from preprocessing.normalization import MachineParameters, FittedScalers, prepare_frame
from preprocessing.split_utils import window_records
from scripts.common import ROOT, load_config, set_seed, json_dump
from scripts.evaluate_metrics import evaluate_predictions
from scripts.generate_synthetic_data import generate_runtime
from scripts.train_dacg import run_experiment, make_loader, predict

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--output', type=Path, default=Path('artifacts/excerpt_inference'))
    p.add_argument('--train-synthetic', action='store_true')
    p.add_argument('--epochs', type=int, default=2)
    args = p.parse_args()
    if args.train_synthetic:
        config = generate_runtime(args.output / 'runtime_data')
        cfg = load_config(config)
        cfg['hyperparameters']['max_epochs'] = args.epochs
        result = run_experiment(cfg, 'CS-L1', args.seed, 'dacg', args.output / 'training', args.device)
        print('synthetic', result['metrics']['test'])
        return
    set_seed(args.seed)
    if args.device == 'cuda' and (not torch.cuda.is_available()):
        raise RuntimeError('CUDA unavailable.')
    ckpt = torch.load(ROOT / 'checkpoints/synthetic_smoke_seed_0.pth', map_location='cpu', weights_only=True)
    if ckpt['provenance']['data_kind'] != 'synthetic':
        raise ValueError('Expected explicitly synthetic smoke checkpoint.')
    machine = MachineParameters(**ckpt['machine'])
    scalers = FittedScalers.from_state_dict(ckpt['scalers'])
    frame = pd.read_csv(ROOT / 'data/demo_dataset/demo_target_data.csv')
    if len(frame) != 10:
        raise ValueError('Submission target excerpt must contain exactly ten data rows.')
    ready = prepare_frame(frame, machine)
    source = pd.read_csv(ROOT / 'data/demo_dataset/demo_source_data.csv')
    if len(source) != 10:
        raise ValueError('Submission source excerpt must contain exactly ten data rows.')
    window_records(scalers.transform(prepare_frame(source, machine)))
    data = window_records(scalers.transform(ready))
    device = torch.device(args.device)
    model = build_dacg_model(device)
    info = verify_dacg_parameters(model)
    model.load_state_dict(ckpt['state_dict'], strict=True)
    metrics, arrays = evaluate_predictions(predict(model, make_loader(data, 64, False), device), data, scalers, machine)
    args.output.mkdir(parents=True, exist_ok=False)
    json_dump(args.output / 'inference.json', {'data_kind': 'synthetic', 'rows': len(frame), 'windows': len(data['y']), 'parameters': info, 'metrics': metrics})
    print('PASS')
    None
if __name__ == '__main__':
    main()
