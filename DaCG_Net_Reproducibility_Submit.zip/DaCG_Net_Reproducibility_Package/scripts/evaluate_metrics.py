import numpy as np
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from preprocessing.pressure import design_matrix, reconstruct

def reconstruct_chamber_pressure_field(coeffs, sensor_angles_deg=(30, 90, 110, 190, 240, 260), *, static_earth_pressure_kpa, sensor_radius_m=3.14, reference_radius_m=1.0):
    angular = np.asarray(coeffs) @ design_matrix(sensor_angles_deg).T
    ps_bar = np.asarray(static_earth_pressure_kpa, dtype=float) / 100.0
    radius = np.asarray(sensor_radius_m, dtype=float)
    if not np.isfinite(ps_bar).all() or (ps_bar <= 0).any() or (not np.isfinite(radius).all()) or (radius <= 0).any() or (not np.isfinite(reference_radius_m)) or (reference_radius_m <= 0):
        raise ValueError('Finite positive earth pressure and radii are required.')
    if ps_bar.ndim == 1:
        ps_bar = ps_bar[:, None]
    return angular * np.log(radius / reference_radius_m) / ps_bar

def compute_metrics(y_true, y_pred, prefix='metric'):
    a, b = (np.asarray(y_true), np.asarray(y_pred))
    if a.ndim != 2 or a.shape != b.shape or len(a) < 2:
        raise ValueError('Metrics require matching matrices with >=2 samples.')
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('Non-finite metric input.')
    result = {}
    for name, fn in [('r2', r2_score), ('mae', mean_absolute_error), ('mse', mean_squared_error)]:
        values = fn(a, b, multioutput='raw_values', **{'force_finite': False} if name == 'r2' else {})
        valid = np.isfinite(values)
        result[f'{prefix}_{name}_mean'] = float(values[valid].mean()) if valid.any() else None
        result[f'{prefix}_{name}_per_output'] = [float(v) if np.isfinite(v) else None for v in values]
    valid_mape = np.abs(a) > 1e-06
    result[f'{prefix}_mape_mean_pct'] = float((np.abs(a - b)[valid_mape] / np.abs(a)[valid_mape]).mean() * 100) if valid_mape.any() else None
    result[f'{prefix}_mape_excluded_count'] = int((~valid_mape).sum())
    return result

def evaluate_predictions(pred_scaled, data, scalers, machine):
    true_coeff = scalers.inverse_coefficients(data['y'])
    pred_coeff = scalers.inverse_coefficients(pred_scaled)
    frame = data['current_frame']
    args = (frame, machine.pressure_convention, machine.pressure_reference_radius_m)
    fitted = reconstruct(true_coeff, *args)
    predicted = reconstruct(pred_coeff, *args)
    measured = data['y_sensors']
    metrics = {}
    for label, truth, pred in [('coeff', true_coeff, pred_coeff), ('fitted_field', fitted, predicted), ('measured_field', measured, predicted)]:
        metrics.update(compute_metrics(truth, pred, label))
    return (metrics, {'true_coeff': true_coeff, 'pred_coeff': pred_coeff, 'measured_bar': measured, 'predicted_bar': predicted, 'fitted_reference_bar': fitted})
