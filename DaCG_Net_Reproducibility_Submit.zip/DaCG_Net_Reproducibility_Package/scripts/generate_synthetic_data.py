import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import yaml
from scripts.common import ROOT, DEFAULT_CONFIG, json_dump
from preprocessing.pressure import design_matrix, DEFAULT_SENSOR_RADIUS_M
from preprocessing.schema import SENSORS, ANGLES, RADII

def generate_raw(rows, seed, angles, domain_shift=0.0):
    if rows < 10:
        raise ValueError('At least ten records are needed for two fixed-input windows.')
    rng = np.random.default_rng(seed)
    t = np.arange(rows) / 35.0
    s = np.sin(t) + 0.25 * np.sin(t * 0.37)
    c = np.cos(t * 0.72)
    ps = 230 + 18 * s + 10 * domain_shift
    advance = 35 + 5 * s + domain_shift
    rotation = 1.3 + 0.15 * c
    area = np.pi * 3.3 ** 2
    volume = advance / 1000 * area
    df = pd.DataFrame({'Sample_Index': np.arange(rows), 'Excavation_Ring': np.ones(rows, dtype=int), 'Bentonite_m3_min': volume * (0.08 + 0.01 * c), 'Foam_Liquid_m3_min': volume * (0.025 + 0.003 * s), 'Foam_Air_m3_min': volume * (0.3 + 0.02 * c), 'Total_Thrust_kN': area * ps * (0.85 + 0.05 * s), 'Advance_mm_min': advance, 'Cutter_RPM': rotation, 'Cutter_Torque_kNm': 600 + 40 * s + 20 * domain_shift, 'Screw_RPM': 8 + 0.5 * s, 'Thrust_A_MPa': 12 + 0.8 * s, 'Thrust_B_MPa': 12 + 0.5 * c, 'Thrust_C_MPa': 11 - 0.5 * s, 'Thrust_D_MPa': 11 - 0.4 * c, 'Displacement_A_mm': 500 + 3 * s, 'Displacement_B_mm': 500 + 2 * c, 'Displacement_C_mm': 500 - 2 * s, 'Displacement_D_mm': 500 - c, 'Gate_Upper_mm': 300 + 20 * s, 'Gate_Lower_mm': 280 + 15 * c, 'Roll_deg': 0.2 * s, 'Pitch_deg': 0.3 * c, 'Cover_Depth_m': 20 + 0.4 * s, 'Groundwater_Depth_m': 12 + 0.2 * c, 'Static_Earth_Pressure_kPa': ps, 'Face_Strength_MPa': 4 + 0.2 * s, 'SPT': 18 + 1.2 * c, 'Poisson_Ratio': 0.3 + 0.01 * s})
    coeff = np.column_stack([1.6 + 0.15 * s + 0.05 * domain_shift, -0.22 + 0.025 * c, 0.04 + 0.012 * np.sin(t * 0.63), 0.025 + 0.006 * np.cos(t * 0.41)])
    pressure = coeff @ design_matrix(angles).T * np.log(DEFAULT_SENSOR_RADIUS_M / 1.0) / (ps[:, None] / 100.0)
    pressure += rng.normal(0, 1e-05, pressure.shape)
    df[SENSORS] = pressure
    df[ANGLES] = np.broadcast_to(angles, (rows, 6))
    df[RADII] = DEFAULT_SENSOR_RADIUS_M
    return df

def generate_runtime(output, rows=1000, seed=2026):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    cfg = yaml.safe_load(DEFAULT_CONFIG.read_text(encoding='utf-8'))
    layouts = cfg['sensor_layouts_deg']
    generate_raw(rows, seed, layouts['CS-L1']).to_csv(output / 'synthetic_source.csv', index=False)
    for i, (task, angles) in enumerate(layouts.items(), 1):
        generate_raw(rows, seed + i, angles, 0.2 * i).to_csv(output / f'synthetic_{task}.csv', index=False)
        cfg['tasks'][task]['source_csv'] = str(output / 'synthetic_source.csv')
        cfg['tasks'][task]['target_csv'] = str(output / f'synthetic_{task}.csv')
        cfg['tasks'][task]['data_kind'] = 'synthetic'
    cfg_path = output / 'synthetic_config.yaml'
    cfg_path.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding='utf-8')
    json_dump(output / 'SYNTHETIC_PROVENANCE.json', {'data_kind': 'synthetic', 'generator_seed': seed, 'rows_per_csv': rows})
    return cfg_path
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rows', type=int, default=1000)
    parser.add_argument('--seed', type=int, default=2026)
    args = parser.parse_args()
    print(generate_runtime(args.output, args.rows, args.seed))
