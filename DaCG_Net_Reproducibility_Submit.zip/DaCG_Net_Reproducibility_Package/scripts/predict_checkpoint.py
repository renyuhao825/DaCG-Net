import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
import torch
from models.dacg_net import build_dacg_model
from preprocessing.normalization import MachineParameters, FittedScalers, prepare_frame
from preprocessing.split_utils import window_records
from scripts.common import set_seed, json_dump
from scripts.train_dacg import make_loader, predict
from scripts.evaluate_metrics import evaluate_predictions
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    ckpt = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    set_seed(ckpt['provenance']['seed'])
    model = build_dacg_model(torch.device('cpu'))
    model.load_state_dict(ckpt['state_dict'], strict=True)
    machine = MachineParameters(**ckpt['machine'])
    scalers = FittedScalers.from_state_dict(ckpt['scalers'])
    data = window_records(scalers.transform(prepare_frame(pd.read_csv(args.input), machine, ckpt['config']['preprocessing']['input_stage'], ckpt['config']['preprocessing']['method'])), ckpt['config']['preprocessing']['r2_threshold'])
    metrics, arrays = evaluate_predictions(predict(model, make_loader(data, 64, False), 'cpu'), data, scalers, machine)
    args.output.mkdir(parents=True, exist_ok=False)
    values = {'Row_ID': data['row_ids'][:, -1]}
    for key, array in arrays.items():
        for j in range(array.shape[1]):
            values[f'{key}_{j + 1}'] = array[:, j]
    pd.DataFrame(values).to_csv(args.output / 'predictions.csv', index=False)
    json_dump(args.output / 'metrics.json', metrics)
