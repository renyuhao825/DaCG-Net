import argparse
import itertools
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from scipy import stats
from scripts.common import DEFAULT_CONFIG, MODES, load_config, parse_seeds, json_dump
from scripts.train_dacg import run_experiment
METRICS = ['measured_field_r2_mean', 'measured_field_mae_mean', 'measured_field_mse_mean', 'measured_field_mape_mean_pct']

def summarize(results, output):
    output = Path(output)
    rows = []
    for result in results:
        p = result['provenance']
        rows.append({**{k: p[k] for k in ['task', 'seed', 'mode', 'data_kind', 'source_sha256', 'target_sha256', 'code_sha256', 'protocol_sha256']}, **{k: result['metrics']['test'][k] for k in METRICS}})
    df = pd.DataFrame(rows)
    if df.duplicated(['task', 'seed', 'mode']).any():
        raise ValueError('Duplicate task/seed/method result.')
    df.to_csv(output / 'per_seed_results.csv', index=False)
    summary = df.groupby(['task', 'data_kind', 'mode'])[METRICS].agg(['count', 'mean', 'std'])
    summary.to_csv(output / 'mean_sd.csv')
    paired = []
    for task, group in df.groupby('task'):
        for identity in ['source_sha256', 'target_sha256', 'code_sha256', 'protocol_sha256']:
            if group[identity].nunique() != 1:
                raise ValueError('Comparisons require the same data, code and protocol: ' + identity)
        for baseline in MODES[1:]:
            a = group[group['mode'] == 'dacg'].set_index('seed')
            b = group[group['mode'] == baseline].set_index('seed')
            if len(a) == 0 or len(b) == 0:
                continue
            if set(a.index) != set(b.index):
                raise ValueError('Paired comparisons require identical seed sets.')
            b = b.loc[a.index]
            for h in ['source_sha256', 'target_sha256']:
                if not (a[h] == b[h]).all():
                    raise ValueError('Paired runs must use identical data files.')
            for metric in METRICS:
                if a[metric].isna().any() or b[metric].isna().any():
                    raise ValueError('Undefined metric cannot enter statistical comparisons.')
                d = a[metric].to_numpy() - b[metric].to_numpy()
                n = len(d)
                if n < 2:
                    continue
                sd = float(d.std(ddof=1))
                if sd == 0:
                    p = 1.0 if np.all(d == 0) else None
                    ci = [float(d.mean()), float(d.mean())]
                else:
                    p = float(stats.ttest_rel(a[metric], b[metric]).pvalue)
                    margin = float(stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n))
                    ci = [float(d.mean() - margin), float(d.mean() + margin)]
                w = 1.0 if np.all(d == 0) else float(stats.wilcoxon(d).pvalue)
                shapiro = float(stats.shapiro(d).pvalue) if n >= 3 and sd > 0 else None
                paired.append({'task': task, 'baseline': baseline, 'metric': metric, 'n': n, 'difference': 'DaCG minus baseline', 'mean_difference': float(d.mean()), 'difference_ci95_low': ci[0], 'difference_ci95_high': ci[1], 'paired_t_p': p, 'wilcoxon_p': w, 'shapiro_difference_p': shapiro, 'effect_dz': float(d.mean() / sd) if sd > 0 else None})
    for task in {r['task'] for r in paired}:
        family = [r for r in paired if r['task'] == task and r['paired_t_p'] is not None]
        family.sort(key=lambda r: r['paired_t_p'])
        last = 0.0
        for i, row in enumerate(family):
            last = min(1.0, max(last, (len(family) - i) * row['paired_t_p']))
            row['paired_t_p_holm'] = last
    pd.DataFrame(paired).to_csv(output / 'paired_statistics.csv', index=False)
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--tasks', default='CS-L1,TJ-L6,HF-L7')
    parser.add_argument('--seeds')
    parser.add_argument('--modes', default=','.join(MODES))
    parser.add_argument('--max_epochs', type=int)
    parser.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--no-checkpoints', action='store_true')
    args = parser.parse_args()
    cfg = load_config(args.config)
    if args.max_epochs is not None:
        cfg['hyperparameters']['max_epochs'] = args.max_epochs
    seeds = parse_seeds(args.seeds) if args.seeds else cfg['execution']['seeds']
    args.output.mkdir(parents=True, exist_ok=False)
    results = []
    for task, mode, seed in itertools.product(args.tasks.split(','), args.modes.split(','), seeds):
        print(f'{task} / {mode} / seed {seed}', flush=True)
        result = run_experiment(cfg, task, seed, mode, args.output / f'{task}_{mode}_seed{seed}', args.device, save_checkpoint=not args.no_checkpoints)
        results.append(result)
    summarize(results, args.output)
if __name__ == '__main__':
    main()
