import argparse
import copy
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.common import MODES, load_config, parse_seeds
from scripts.train_dacg import run_experiment
from scripts.run_experiments import summarize

def variants(cfg, analysis):
    if analysis == 'lambda':
        options = [(0.1, 'lambda_0.1'), (0.01, 'lambda_0.01'), (0.001, 'lambda_0.001'), (0.0001, 'lambda_0.0001')]
    elif analysis == 'preprocessing':
        options = [('dimensionless', 'dimensionless_minmax'), ('raw_zscore', 'raw_zscore')]
    elif analysis == 'target_size':
        options = [(v, f'target_{v}') for v in [0.1, 0.2, 0.3, 0.4, 0.5]]
    else:
        options = [(v, f'shift_{v}') for v in [0, 0.2, 0.4, 0.6]]
    for value, label in options:
        new = copy.deepcopy(cfg)
        if analysis == 'lambda':
            new['hyperparameters']['coral_lambda'] = value
        elif analysis == 'preprocessing':
            new['preprocessing']['method'] = value
        elif analysis == 'target_size':
            new['splits']['target'] = {'train': [0, value * 0.8], 'val': [value * 0.8, value], 'test': [0.6, 0.7]}
        else:
            new['splits']['target'] = {'train': [value, value + 0.08], 'val': [value + 0.08, value + 0.1], 'test': [value + 0.1, value + 0.2]}
        yield (label, new)
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--data-dir', type=Path)
    p.add_argument('--analysis', choices=['lambda', 'preprocessing', 'target_size', 'temporal'], required=True)
    p.add_argument('--tasks', default='CS-L1,TJ-L6,HF-L7')
    p.add_argument('--seeds', default='0-9')
    p.add_argument('--modes', default='dacg')
    p.add_argument('--max_epochs', type=int)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    cfg = load_config(data_dir=args.data_dir)
    if args.max_epochs is not None:
        cfg['hyperparameters']['max_epochs'] = args.max_epochs
    args.output.mkdir(parents=True, exist_ok=False)
    for label, variant in variants(cfg, args.analysis):
        folder = args.output / label
        folder.mkdir()
        results = []
        for task in args.tasks.split(','):
            for mode in args.modes.split(','):
                for seed in parse_seeds(args.seeds):
                    print(label, task, mode, seed, flush=True)
                    results.append(run_experiment(variant, task, seed, mode, folder / f'{task}_{mode}_{seed}', save_checkpoint=False))
        summarize(results, folder)
