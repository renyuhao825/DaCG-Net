import argparse
import copy
import itertools
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from scripts.common import DEFAULT_CONFIG, load_config, json_dump
from scripts.train_dacg import run_experiment
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    p.add_argument('--task', default='CS-L1')
    p.add_argument('--candidates', type=int, default=100)
    p.add_argument('--folds', type=int, default=10)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--max_epochs', type=int)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    cfg = load_config(args.config)
    if args.max_epochs is not None:
        cfg['hyperparameters']['max_epochs'] = args.max_epochs
    n = len(pd.read_csv(cfg['tasks'][args.task]['target_csv']))
    a, b = cfg['splits']['target']['train']
    blocks = np.array_split(np.arange(int(n * a), int(n * b)), args.folds)
    if args.folds < 2 or min(map(len, blocks)) < 10:
        raise ValueError('Each CV block needs >=10 raw rows (prefer many more). Increase authorized/runtime data; do not reuse ten-row excerpts.')
    grid = list(itertools.product([0.1, 0.01, 0.001, 0.0001, 1e-05], [0.001, 0.0001, 1e-05], [16, 32, 64, 128, 512, 1024], [0.1, 0.01, 0.001, 0.0001]))
    if not 1 <= args.candidates <= len(grid):
        raise ValueError('Candidate count exceeds unique training-only search space.')
    rng = np.random.default_rng(args.seed)
    chosen = rng.choice(len(grid), args.candidates, replace=False)
    args.output.mkdir(parents=True, exist_ok=False)
    json_dump(args.output / 'fold_indices.json', [v.tolist() for v in blocks])
    candidates = []
    for candidate_id, grid_id in enumerate(chosen):
        pre, ft, batch, weight = grid[int(grid_id)]
        variant = copy.deepcopy(cfg)
        variant['hyperparameters'].update(pretrain_learning_rate=pre, finetune_learning_rate=ft, batch_size=batch, coral_lambda=weight)
        scores = []
        failure = None
        for fold in range(args.folds):
            training = np.sort(np.concatenate([v for j, v in enumerate(blocks) if j != fold]))
            override = {'train': training.tolist(), 'val': blocks[fold].tolist()}
            print('candidate', candidate_id, 'fold', fold, flush=True)
            try:
                result = run_experiment(variant, args.task, args.seed, 'dacg', args.output / f'candidate{candidate_id}_fold{fold}', target_override=override, evaluate_test=False, save_checkpoint=False)
            except FloatingPointError as exc:
                failure = str(exc)
                break
            score = result['metrics']['val']['measured_field_r2_mean']
            if score is None:
                raise ValueError('CV R2 undefined; candidate cannot be selected.')
            scores.append(score)
        candidates.append({'candidate': candidate_id, 'pretrain_lr': pre, 'finetune_lr': ft, 'batch_size': batch, 'coral_lambda': weight, 'fold_r2': scores, 'status': 'failed' if failure else 'completed', 'failure': failure, 'mean_validation_r2': float(np.mean(scores)) if not failure else None})
        json_dump(args.output / 'search_results.json', candidates)
    valid = [row for row in candidates if row['status'] == 'completed']
    if not valid:
        raise RuntimeError('Every candidate failed; inspect search_results.json. No config selected.')
    best = max(valid, key=lambda v: v['mean_validation_r2'])
    json_dump(args.output / 'selected_training_parameters.json', best)
    import yaml
    selected = copy.deepcopy(cfg)
    selected.pop('_config_path', None)
    selected['hyperparameters'].update(pretrain_learning_rate=best['pretrain_lr'], finetune_learning_rate=best['finetune_lr'], batch_size=best['batch_size'], coral_lambda=best['coral_lambda'])
    (args.output / 'selected_config.yaml').write_text(yaml.safe_dump(selected, sort_keys=False), encoding='utf-8')
