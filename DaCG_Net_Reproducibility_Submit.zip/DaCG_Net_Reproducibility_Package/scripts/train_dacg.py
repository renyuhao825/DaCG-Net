import argparse
import copy
import hashlib
import json
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, TensorDataset, Sampler
from models.dacg_net import build_dacg_model, verify_dacg_parameters, set_dacg_finetune_trainable
from preprocessing.normalization import MachineParameters, FittedScalers, prepare_frame
from preprocessing.schema import FEATURES, COEFFICIENTS
from preprocessing.split_utils import split_records, window_records
from scripts.common import MODES, load_config, set_seed, sha256, code_fingerprint, json_dump
from scripts.evaluate_metrics import evaluate_predictions

class BatchesWithoutSingleton(Sampler):

    def __init__(self, n, batch_size, shuffle):
        if n < 2 or batch_size < 2:
            raise ValueError('Training/metrics require >=2 samples and batch_size>=2.')
        self.n, self.size, self.shuffle = (n, batch_size, shuffle)

    def __iter__(self):
        indices = torch.randperm(self.n).tolist() if self.shuffle else list(range(self.n))
        chunks = [indices[i:i + self.size] for i in range(0, self.n, self.size)]
        if len(chunks) > 1 and len(chunks[-1]) == 1:
            tail = chunks.pop()
            chunks[-1].extend(tail)
        yield from chunks

    def __len__(self):
        count = (self.n + self.size - 1) // self.size
        return count - int(count > 1 and self.n % self.size == 1)

def make_loader(data, batch_size, shuffle):
    tensors = [torch.tensor(data[k], dtype=torch.float32) for k in ['x_cnn', 'x_rnn', 'x_crnn', 'y']]
    return DataLoader(TensorDataset(*tensors), batch_sampler=BatchesWithoutSingleton(len(tensors[0]), batch_size, shuffle))

def prepare_data(cfg, task_id, mode, target_override=None):
    task = cfg['tasks'][task_id]
    if task['data_kind'] == 'authorized_project_required':
        raise ValueError('Configure authorized project CSVs, provenance and actual machine parameters first.')
    if task['data_kind'] == 'authorized_project':
        from dataclasses import fields
        required = {field.name for field in fields(MachineParameters)}
        for key in ['source_machine', 'target_machine']:
            if not required <= set(task[key]):
                raise ValueError('Authorized project data require explicit complete ' + key + ' parameters.')
    machine_s = MachineParameters(**task['source_machine'])
    machine_t = MachineParameters(**task['target_machine'])
    stage, method = (cfg['preprocessing']['input_stage'], cfg['preprocessing']['method'])
    source = prepare_frame(pd.read_csv(task['source_csv']), machine_s, stage, method)
    target = prepare_frame(pd.read_csv(task['target_csv']), machine_t, stage, method)
    src = split_records(source, cfg['splits']['source'])
    tgt = split_records(target, cfg['splits']['target'])
    if target_override is not None:
        allowed = set(tgt['train']['Row_ID'])
        ids = set(target_override['train']) | set(target_override['val'])
        if not ids <= allowed or set(target_override['train']) & set(target_override['val']):
            raise ValueError('CV folds must be disjoint subsets of outer target training records.')
        tgt = {key: target.iloc[indices].copy() for key, indices in target_override.items()}
    for domain, parts in [('source', src), ('target', tgt)]:
        for name, frame in parts.items():
            if len(frame) < 10:
                raise ValueError(f'{domain}/{name} has {len(frame)} rows; each partition needs at least ten raw rows and two valid windows. Ten-row submission excerpts support inference only; generate runtime synthetic data or supply sufficient authorized records.')
    fit_frames = [tgt['train']] if mode == 'target_only' else [src['train'], tgt['train']]
    scalers = FittedScalers(method).fit(fit_frames)
    threshold = cfg['preprocessing']['r2_threshold']
    source_data = {k: window_records(scalers.transform(v), threshold) for k, v in src.items()}
    target_data = {k: window_records(scalers.transform(v), threshold) for k, v in tgt.items()}
    indices = {domain: {key: {'raw_rows': frame['Row_ID'].tolist(), 'window_rows': data[key]['row_ids'].tolist()} for key, frame in partitions.items()} for domain, partitions, data in [('source', src, source_data), ('target', tgt, target_data)]}
    return (source_data, target_data, scalers, machine_t, indices)

def predict(model, loader, device):
    model.eval()
    values = []
    with torch.no_grad():
        for *inputs, _ in loader:
            pred, _ = model(*(x.to(device) for x in inputs))
            values.append(pred.cpu().numpy())
    return np.concatenate(values)

def fit_stage(model, source_loader, target_loader, val_loader, device, hp, lr, use_coral):
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.Adam(params, lr=lr)
    if hp['scheduler'] == 'CosineAnnealingLR':
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=hp['max_epochs'], eta_min=hp.get('scheduler_eta_min', 0.0))
    else:
        raise ValueError('Unsupported scheduler.')
    best_loss, best, best_epoch, stale = (float('inf'), None, 0, 0)
    logs = []
    started = time.perf_counter()
    for epoch in range(1, hp['max_epochs'] + 1):
        model.train()
        target_it = iter(target_loader) if use_coral else None
        total, total_reg, total_coral, count = (0.0, 0.0, 0.0, 0)
        for *inputs, labels in source_loader:
            inputs, labels = ([x.to(device) for x in inputs], labels.to(device))
            if use_coral:
                try:
                    batch = next(target_it)
                except StopIteration:
                    target_it = iter(target_loader)
                    batch = next(target_it)
                pred, coral = model(*inputs, *(x.to(device) for x in batch[:3]))
            else:
                pred, _ = model(*inputs)
                coral = pred.new_zeros(())
            regression = torch.nn.functional.mse_loss(pred, labels)
            loss = regression + hp['coral_lambda'] * coral
            if not torch.isfinite(loss):
                raise FloatingPointError('Non-finite training loss; check data/configuration.')
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            n = len(labels)
            total += float(loss.detach()) * n
            total_reg += float(regression.detach()) * n
            total_coral += float(coral.detach()) * n
            count += n
        model.eval()
        error, nval = (0.0, 0)
        with torch.no_grad():
            for *vin, vy in val_loader:
                vp, _ = model(*(x.to(device) for x in vin))
                error += float(torch.nn.functional.mse_loss(vp, vy.to(device), reduction='sum'))
                nval += vy.numel()
        value = error / nval
        if not np.isfinite(value):
            raise FloatingPointError('Non-finite validation loss.')
        logs.append({'epoch': epoch, 'loss': total / count, 'regression': total_reg / count, 'coral': total_coral / count, 'val_mse': value, 'lr': optimizer.param_groups[0]['lr']})
        if value < best_loss:
            best_loss, best_epoch, stale = (value, epoch, 0)
            best = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
        scheduler.step()
        if stale >= hp['early_stopping_patience']:
            break
    model.load_state_dict(best)
    return {'best_epoch': best_epoch, 'best_val_mse': best_loss, 'history': logs, 'seconds': time.perf_counter() - started}

def run_experiment(cfg, task_id, seed, mode, output, device_name='cpu', target_override=None, evaluate_test=True, save_checkpoint=True):
    if mode not in MODES:
        raise ValueError(mode)
    if device_name == 'cuda' and (not torch.cuda.is_available()):
        raise RuntimeError('CUDA requested but unavailable; use --device cpu explicitly.')
    set_seed(seed, cfg['execution']['cpu_threads'])
    device = torch.device(device_name)
    out = Path(output)
    out.mkdir(parents=True, exist_ok=False)
    hp = cfg['hyperparameters']
    if hp['max_epochs'] < 1:
        raise ValueError('max_epochs must be >=1.')
    src, tgt, scalers, machine, indices = prepare_data(cfg, task_id, mode, target_override)
    split_summary = {'fractions': copy.deepcopy(cfg['splits']), 'target_cv_override': target_override is not None, 'pretrain_validation': 'source/val', 'finetune_validation': 'target/val', 'partitions': {domain: {part: {'raw_rows': len(values['raw_rows']), 'valid_windows': len(values['window_rows'])} for part, values in partitions.items()} for domain, partitions in indices.items()}}
    json_dump(out / 'split_summary.json', split_summary)
    sl = {k: make_loader(v, hp['batch_size'], k == 'train') for k, v in src.items()}
    tl = {k: make_loader(v, hp['batch_size'], k == 'train') for k, v in tgt.items()}
    model = build_dacg_model(device)
    info = verify_dacg_parameters(model)
    for p in model.parameters():
        p.requires_grad_(True)
    training = {}
    if mode != 'target_only':
        training['pretrain'] = fit_stage(model, sl['train'], tl['train'], sl['val'], device, hp, hp['pretrain_learning_rate'], mode in ['dacg', 'coral_only'])
    if mode in ['dacg', 'finetune_only', 'target_only']:
        if mode != 'target_only':
            set_dacg_finetune_trainable(model)
        training['target'] = fit_stage(model, tl['train'], None, tl['val'], device, hp, hp['finetune_learning_rate'], False)
    evaluation = {}
    for part in ['val'] + (['test'] if evaluate_test else []):
        loader = make_loader(tgt[part], hp['batch_size'], False)
        metrics, arrays = evaluate_predictions(predict(model, loader, device), tgt[part], scalers, machine)
        evaluation[part] = metrics
        values = {'Row_ID': tgt[part]['row_ids'][:, -1]}
        for key, array in arrays.items():
            for j in range(array.shape[1]):
                values[f'{key}_{j + 1}'] = array[:, j]
        pd.DataFrame(values).to_csv(out / f'{part}_predictions.csv', index=False)
    task = cfg['tasks'][task_id]
    protocol = {key: cfg[key] for key in ['architecture', 'hyperparameters', 'preprocessing', 'splits']}
    protocol['machines'] = [task['source_machine'], task['target_machine']]
    provenance = {'task': task_id, 'seed': seed, 'mode': mode, 'data_kind': task['data_kind'], 'source_sha256': sha256(task['source_csv']), 'target_sha256': sha256(task['target_csv']), 'code_sha256': code_fingerprint(), 'python': platform.python_version(), 'torch': str(torch.__version__), 'protocol_sha256': hashlib.sha256(json.dumps(protocol, sort_keys=True).encode()).hexdigest(), 'device': str(device), 'architecture': info, 'pressure_convention': machine.pressure_convention}
    result = {'provenance': provenance, 'split_summary': split_summary, 'training': training, 'metrics': evaluation}
    json_dump(out / 'result.json', result)
    json_dump(out / 'split_indices.json', indices)
    if save_checkpoint:
        torch.save({'format_version': 2, 'state_dict': model.state_dict(), 'history_steps': 7, 'scalers': scalers.state_dict(), 'machine': asdict(machine), 'provenance': provenance, 'training': training}, out / 'checkpoint.pth')
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=Path)
    parser.add_argument('--task', default='CS-L1')
    parser.add_argument('--mode', choices=MODES, default='dacg')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
    parser.add_argument('--max_epochs', type=int)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    cfg = load_config(data_dir=args.data_dir)
    if args.max_epochs is not None:
        cfg['hyperparameters']['max_epochs'] = args.max_epochs
    result = run_experiment(cfg, args.task, args.seed, args.mode, args.output, args.device)
    print(result['metrics']['test'])
if __name__ == '__main__':
    main()
