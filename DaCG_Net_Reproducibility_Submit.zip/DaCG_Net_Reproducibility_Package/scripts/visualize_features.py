import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import torch
from sklearn.manifold import TSNE
from models.dacg_net import build_dacg_model
from preprocessing.normalization import FittedScalers
from scripts.common import set_seed
from scripts.train_dacg import prepare_data
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--config', type=Path)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--max-points', type=int, default=300)
    p.add_argument('--figure', type=Path)
    args = p.parse_args()
    ckpt = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    cfg, prov = (ckpt['config'], ckpt['provenance'])
    if args.config:
        from scripts.common import load_config
        cfg = load_config(args.config)
    from scripts.common import sha256
    task = cfg['tasks'][prov['task']]
    if sha256(task['source_csv']) != prov['source_sha256'] or sha256(task['target_csv']) != prov['target_sha256']:
        raise ValueError('Feature visualization needs exactly the checkpoint training datasets.')
    set_seed(prov['seed'])
    src, tgt, _, _, _ = prepare_data(cfg, prov['task'], prov['mode'])
    initial = build_dacg_model(torch.device('cpu')).eval()
    trained = build_dacg_model(torch.device('cpu')).eval()
    trained.load_state_dict(ckpt['state_dict'], strict=True)
    arrays, labels = ([], [])
    for domain, data in [('source', src['train']), ('target', tgt['train'])]:
        ix = np.linspace(0, len(data['y']) - 1, min(len(data['y']), args.max_points), dtype=int)
        arrays.append([torch.tensor(data[k][ix]) for k in ['x_cnn', 'x_rnn', 'x_crnn']])
        labels += [domain] * len(ix)
    rows = []
    with torch.no_grad():
        for stage, model in [('initial', initial), ('trained', trained)]:
            features = np.concatenate([model.encode(*inputs).numpy() for inputs in arrays])
            projection = TSNE(n_components=2, random_state=prov['seed'], perplexity=min(30, len(features) - 1), init='random', n_jobs=1).fit_transform(features)
            rows.extend(({'stage': stage, 'domain': label, 'x': float(x), 'y': float(y)} for label, (x, y) in zip(labels, projection)))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.output, index=False)
    if args.figure:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        table = pd.DataFrame(rows)
        fig, axes = plt.subplots(1, 2, figsize=(7, 3), layout='constrained')
        for axis, stage in zip(axes, ['initial', 'trained']):
            for domain, color in [('source', '#0072B2'), ('target', '#D55E00')]:
                part = table[(table.stage == stage) & (table.domain == domain)]
                axis.scatter(part.x, part.y, s=10, color=color, label=domain, alpha=0.7)
            axis.set(title=stage, xlabel='t-SNE 1', ylabel='t-SNE 2')
            axis.legend(frameon=False)
        fig.suptitle(prov['data_kind'] + ' training features; projections fitted separately')
        args.figure.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(args.figure, dpi=200)
        plt.close(fig)
