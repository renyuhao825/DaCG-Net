import copy
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import torch
from models.dacg_net import build_dacg_model, verify_dacg_parameters, set_dacg_finetune_trainable
from models.coral_loss import coral_loss
from models.baseline_models import build_baseline_model
from preprocessing.normalization import DimensionlessPreprocessor, FittedScalers, prepare_frame, MachineParameters
from preprocessing.schema import FEATURES, COEFFICIENTS, ANGLES, SENSORS, RADII
from preprocessing.pressure import fit_pressure_coefficients, reconstruct
from preprocessing.split_utils import split_records, window_records
from scripts.common import load_config, set_seed
from scripts.generate_synthetic_data import generate_raw, generate_runtime
from scripts.train_dacg import BatchesWithoutSingleton, prepare_data, run_experiment

class CorrectnessTests(unittest.TestCase):

    def setUp(self):
        set_seed(0)
        self.model = build_dacg_model(torch.device('cpu'))
        self.inputs = (torch.randn(5, 1, 7, 22), torch.randn(5, 7, 4), torch.randn(5, 15))

    def test_architecture_and_inspection_no_side_effect(self):
        flags = [p.requires_grad for p in self.model.parameters()]
        info = verify_dacg_parameters(self.model)
        self.assertEqual(info['total_parameters'], 1528140)
        self.assertEqual(info['finetune_parameters'], 185028)
        self.assertEqual(flags, [p.requires_grad for p in self.model.parameters()])
        self.assertEqual([(k, tuple(v.shape)) for k, v in self.model.state_dict().items()], [(k, tuple(v.shape)) for k, v in build_baseline_model(torch.device('cpu')).state_dict().items()])

    def test_pretrain_updates_backbone_and_finetune_freezes(self):
        initial = self.model.gru2.weight_ih_l0.detach().clone()
        optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)
        pred, loss = self.model(*self.inputs, *self.inputs)
        (pred.square().mean() + 0.01 * loss).backward()
        optimizer.step()
        self.assertFalse(torch.equal(initial, self.model.gru2.weight_ih_l0))
        frozen = {k: v.clone() for k, v in self.model.state_dict().items()}
        optimizer = torch.optim.Adam(set_dacg_finetune_trainable(self.model), lr=0.001)
        optimizer.zero_grad(set_to_none=True)
        pred, _ = self.model(*self.inputs)
        (pred - torch.ones_like(pred)).square().mean().backward()
        optimizer.step()
        for k, v in self.model.state_dict().items():
            if not k.startswith(('fc.', 'bottleneck.', 'final_fc.')):
                self.assertTrue(torch.equal(v, frozen[k]), k)
        self.assertFalse(torch.equal(self.model.final_fc[0].weight, frozen['final_fc.0.weight']))

    def test_batch_invariance_and_order(self):
        self.model.eval()
        with torch.no_grad():
            pred, _ = self.model(*self.inputs)
            perm = torch.tensor([4, 3, 2, 1, 0])
            shuffled, _ = self.model(*(v[perm] for v in self.inputs))
            alone, _ = self.model(*(v[2:3] for v in self.inputs))
            changed = tuple((v.clone() for v in self.inputs))
            changed[1][0] += 100
            other, _ = self.model(*changed)
        torch.testing.assert_close(pred, shuffled[perm], atol=2e-06, rtol=2e-05)
        torch.testing.assert_close(pred[2], alone[0], atol=2e-06, rtol=2e-05)
        torch.testing.assert_close(pred[1:], other[1:], atol=2e-06, rtol=2e-05)

    def test_coral_against_independent_numpy(self):
        s = torch.randn(7, 5, dtype=torch.float64, requires_grad=True)
        t = torch.randn(11, 5, dtype=torch.float64, requires_grad=True)
        ref = ((np.cov(s.detach().numpy(), rowvar=False) - np.cov(t.detach().numpy(), rowvar=False)) ** 2).sum() / 100
        actual = coral_loss(s, t)
        self.assertAlmostEqual(float(actual.detach()), ref, places=12)
        actual.backward()
        self.assertTrue(torch.isfinite(s.grad).all())
        self.assertEqual(float(coral_loss(s, s).detach()), 0)
        with self.assertRaises(ValueError):
            coral_loss(s[:1], t)

    def test_physical_formulas_and_pressure(self):
        raw = generate_raw(30, 8, [30, 90, 110, 190, 240, 260])
        frame = prepare_frame(raw, {})
        r = 3.3
        i = 0
        row = raw.iloc[i]
        self.assertAlmostEqual(frame.Thrust_Ratio.iloc[i], row.Total_Thrust_kN / (np.pi * r * r * row.Static_Earth_Pressure_kPa))
        self.assertAlmostEqual(frame.Penetration_Ratio.iloc[i], row.Advance_mm_min / 1000 / (row.Cutter_RPM * 2 * np.pi * r))
        self.assertAlmostEqual(frame.Gate_Combined_Ratio.iloc[i], row.Gate_Upper_mm * row.Gate_Lower_mm / 560 ** 2)
        self.assertAlmostEqual(frame.Torque_Ratio.iloc[i], row.Cutter_Torque_kNm * 1000 / (0.7 * 0.67 * np.pi * r ** 3 * row.Static_Earth_Pressure_kPa * 1000))
        self.assertAlmostEqual(frame.Screw_Discharge_Ratio.iloc[i], np.pi * 0.8 ** 2 * row.Screw_RPM * 0.6 / (row.Advance_mm_min / 1000 * np.pi * r ** 2))
        self.assertAlmostEqual(frame.Vertical_Thrust_Moment.iloc[i], (row.Thrust_A_MPa - row.Thrust_C_MPa) / (row.Thrust_A_MPa + row.Thrust_C_MPa))
        self.assertAlmostEqual(frame.Vertical_Displacement_Bias.iloc[i], (row.Displacement_A_mm - row.Displacement_C_mm) / (2000 * r))
        self.assertAlmostEqual(frame.Roll_rad.iloc[i], np.deg2rad(row.Roll_deg))
        np.testing.assert_allclose(frame[ANGLES], np.broadcast_to([30, 90, 110, 190, 240, 260], (30, 6)))
        self.assertGreater(frame.Fitting_R2.min(), 0.99)
        coeff, _ = fit_pressure_coefficients(raw)
        np.testing.assert_allclose(reconstruct(coeff, raw), raw[SENSORS], atol=4e-05)
        literal, _ = fit_pressure_coefficients(raw, 'table2_literal')
        np.testing.assert_allclose(reconstruct(literal, raw, 'table2_literal'), raw[SENSORS], atol=4e-05)
        raw['Advance_mm_min'] = 0
        with self.assertRaises(ValueError):
            prepare_frame(raw, {})

    def test_preprocessed_contract_rejects_inconsistent_coefficients(self):
        frame = prepare_frame(generate_raw(30, 8, [30, 90, 110, 190, 240, 260]), {}).drop(columns='Row_ID')
        prepare_frame(frame, {}, input_stage='dimensionless')
        frame.loc[0, 'Coeff_a'] += 0.1
        with self.assertRaisesRegex(ValueError, 'coefficients do not match'):
            prepare_frame(frame, {}, input_stage='dimensionless')

    def test_radial_reconstruction_keeps_unscaled_earth_pressure(self):
        raw = generate_raw(50, 8, [30, 90, 110, 190, 240, 260])
        frame = prepare_frame(raw, {'pressure_convention': 'table2_literal'})
        scalers = FittedScalers().fit([frame.iloc[:30]])
        scaled = scalers.transform(frame)
        coeff = scalers.inverse_coefficients(scaled[COEFFICIENTS])
        prediction = reconstruct(coeff, scaled, 'table2_literal')
        np.testing.assert_allclose(prediction, raw[SENSORS], atol=4e-05)

    def test_table2_default_radius_against_independent_formula(self):
        raw = generate_raw(30, 8, [30, 90, 110, 190, 240, 260])
        known = np.tile([1.6, -0.22, 0.04, 0.025], (len(raw), 1))
        theta = np.deg2rad(raw[ANGLES].to_numpy())
        expected = (known[:, :1] + known[:, 1:2] * np.cos(theta) + known[:, 2:3] * np.sin(theta) + known[:, 3:4] * np.cos(2 * theta)) * np.log(3.14) / (raw['Static_Earth_Pressure_kPa'].to_numpy()[:, None] / 100)
        raw[SENSORS] = expected
        no_radii = raw.drop(columns=RADII)
        fitted, quality = fit_pressure_coefficients(no_radii)
        np.testing.assert_allclose(fitted, known, atol=1e-12)
        np.testing.assert_allclose(reconstruct(known, no_radii), expected, atol=1e-12)
        np.testing.assert_allclose(quality, 1)
        from scripts.evaluate_metrics import reconstruct_chamber_pressure_field
        np.testing.assert_allclose(reconstruct_chamber_pressure_field(known, static_earth_pressure_kpa=raw['Static_Earth_Pressure_kPa'].to_numpy()), expected, atol=1e-12)
        self.assertEqual(MachineParameters().pressure_convention, 'table2_literal')
        raw.loc[0, RADII[0]] = np.nan
        with self.assertRaises(ValueError):
            fit_pressure_coefficients(raw)

    def test_scalers_do_not_see_validation_or_test(self):
        frame = prepare_frame(generate_raw(100, 3, [30, 90, 110, 190, 240, 260]), {})
        fit = FittedScalers().fit([frame.iloc[:50]])
        state = copy.deepcopy(fit.state_dict())
        altered = frame.iloc[50:].copy()
        altered[FEATURES] = 1000000000.0
        fit.transform(altered)
        self.assertEqual(state, fit.state_dict())
        restored = FittedScalers.from_state_dict(state)
        scaled = fit.transform(frame)
        np.testing.assert_allclose(restored.inverse_coefficients(scaled[COEFFICIENTS]), frame[COEFFICIENTS])

    def test_strict_split_before_windows(self):
        frame = prepare_frame(generate_raw(200, 3, [30, 90, 110, 190, 240, 260]), {})
        parts = split_records(frame, {'train': [0, 0.5], 'val': [0.5, 0.75], 'test': [0.75, 1]})
        fit = FittedScalers().fit([parts['train']])
        windows = {k: window_records(fit.transform(v)) for k, v in parts.items()}
        for a, b in [('train', 'val'), ('val', 'test'), ('train', 'test')]:
            self.assertFalse(set(windows[a]['row_ids'].ravel()) & set(windows[b]['row_ids'].ravel()))

    def test_singleton_batches_are_merged_not_dropped(self):
        for n in [2, 3, 64, 65, 129]:
            batches = list(BatchesWithoutSingleton(n, 64, False))
            self.assertTrue(all((len(v) >= 2 for v in batches)))
            self.assertEqual(sum(batches, []), list(range(n)))

    def test_ten_rows_not_misrepresented_as_training_split(self):
        with tempfile.TemporaryDirectory() as temp:
            cfg = load_config(generate_runtime(Path(temp) / 'data', 1000))
            cfg['tasks']['CS-L1']['source_csv'] = str(Path(__file__).resolve().parents[1] / 'data/demo_dataset/demo_source_data.csv')
            cfg['tasks']['CS-L1']['target_csv'] = str(Path(__file__).resolve().parents[1] / 'data/demo_dataset/demo_target_data.csv')
            with self.assertRaisesRegex(ValueError, 'at least ten raw rows'):
                prepare_data(cfg, 'CS-L1', 'dacg')

    def test_seven_history_rows_and_next_record_alignment(self):
        frame = prepare_frame(generate_raw(30, 8, [30, 90, 110, 190, 240, 260]), {})
        data = window_records(frame)
        self.assertEqual(data['x_cnn'].shape, (23, 1, 7, 22))
        self.assertEqual(data['x_rnn'].shape, (23, 7, 4))
        np.testing.assert_array_equal(data['row_ids'][0], np.arange(8))
        np.testing.assert_allclose(data['x_rnn'][0, -1], frame[COEFFICIENTS].iloc[6], rtol=1e-6)
        np.testing.assert_allclose(data['y'][0], frame[COEFFICIENTS].iloc[7], rtol=1e-6)

    def test_statistical_improvement_direction_for_all_metrics(self):
        from scripts.run_experiments import summarize, METRICS
        from scripts.common import MODES
        for sign in [-1, 1]:
            results = []
            for seed in range(10):
                gain = sign * (0.01 + seed * 0.001)
                for mode in MODES:
                    values = {m: (0.8 if 'r2' in m else 0.2) for m in METRICS}
                    if mode == 'dacg':
                        for metric in METRICS:
                            values[metric] += gain if 'r2' in metric else -gain
                    provenance = dict(task='CS-L1', seed=seed, mode=mode, data_kind='synthetic_test', source_sha256='s', target_sha256='t', code_sha256='c', protocol_sha256='p')
                    results.append({'provenance': provenance, 'metrics': {'test': values}})
            with tempfile.TemporaryDirectory() as folder:
                summarize(results, folder)
                table = pd.read_csv(Path(folder) / 'paired_statistics.csv')
                self.assertEqual(len(table), 12)
                self.assertTrue((sign * table['mean_difference'] > 0).all())
                self.assertTrue((sign * table['effect_dz'] > 0).all())
                endpoint = 'difference_ci95_low' if sign > 0 else 'difference_ci95_high'
                self.assertTrue((sign * table[endpoint] > 0).all())
                self.assertTrue((table['positive_means'] == 'DaCG improvement').all())
                self.assertTrue((table.loc[table.metric.str.contains('r2'), 'difference'] == 'DaCG minus baseline').all())
                self.assertTrue((table.loc[~table.metric.str.contains('r2'), 'difference'] == 'baseline minus DaCG').all())

    def test_training_reproducibility_and_checkpoint_reload(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp)
            cfg = load_config(generate_runtime(path / 'data', 1000))
            cfg['hyperparameters']['max_epochs'] = 2
            a = run_experiment(cfg, 'CS-L1', 0, 'dacg', path / 'a')
            b = run_experiment(cfg, 'CS-L1', 0, 'dacg', path / 'b')
            self.assertEqual(a['metrics'], b['metrics'])
            self.assertEqual(cfg['hyperparameters']['scheduler'], 'CosineAnnealingLR')
            for stage, rate in [('pretrain', 0.01), ('target', 0.001)]:
                np.testing.assert_allclose([v['lr'] for v in a['training'][stage]['history']], [rate, rate / 2], rtol=1e-12)
            summary = a['split_summary']
            self.assertEqual(summary['pretrain_validation'], 'source/val')
            self.assertEqual(summary['finetune_validation'], 'target/val')
            self.assertEqual({k: v['raw_rows'] for k, v in summary['partitions']['source'].items()}, {'train': 900, 'val': 100})
            self.assertEqual({k: v['raw_rows'] for k, v in summary['partitions']['target'].items()}, {'train': 80, 'val': 20, 'test': 100})
            aa = torch.load(path / 'a/checkpoint.pth', weights_only=True)
            bb = torch.load(path / 'b/checkpoint.pth', weights_only=True)
            for k, v in aa['state_dict'].items():
                self.assertTrue(torch.equal(v, bb['state_dict'][k]))
            model = build_dacg_model(torch.device('cpu'))
            model.load_state_dict(aa['state_dict'], strict=True)
if __name__ == '__main__':
    unittest.main(verbosity=2)
